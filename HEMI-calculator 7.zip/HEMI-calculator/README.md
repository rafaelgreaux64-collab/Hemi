# HEMI — Household Economic Margin Index

Consumer-facing HEMI calculator. Enter monthly take-home income and essential household expenses to see household pressure, monthly essentials, money left, essential-cost share, and expense drivers.

The research HEMI 1.0 framework is intended to use standardized changes in real income, essential costs, and financial burden over time. This web version is the consumer-facing starting point.
